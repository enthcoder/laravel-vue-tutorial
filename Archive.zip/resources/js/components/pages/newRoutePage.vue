<template>
    <div>
        <h1>this is the second new vue page...</h1>
    </div>
</template>