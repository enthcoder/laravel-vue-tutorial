<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Full stack blog</title>

        <link rel="stylesheet" href="/css/all.css">
        <script>
           
            (function () {
                window.Laravel = {
                    csrfToken: '<?php echo e(csrf_token()); ?>'
                };
            })();
          
        </script>
      
    </head>
    <body>
         <div id="app">
             <?php if(Auth::check()): ?>
                <mainapp :user="<?php echo e(Auth::user()); ?>"></mainapp>
            <?php else: ?> 
                <mainapp :user="false"></mainapp>
            <?php endif; ?>
         </div>
    </body>
    <script src="<?php echo e(mix('/js/app.js')); ?>"></script>

</html>
<?php /**PATH /Users/mdzainalabedin/laravel/fullstack/resources/views/welcome.blade.php ENDPATH**/ ?>